public class Person {
	//data-fields
	private int age;
	private double height;
	private double weight;
	private String name;
	private String gender;
	
	//Constructor
	public Person() {
	}
	public Person(String name, String gender, int age, double height, double weight) {
		this.name = name;
		this.gender = gender;
		this.age = age;
		this.height = height;
		this.weight = weight;

	}
	
	//Setters
	public String getName() { return name; }
	public String getGender() { return gender; }
	public int getAge() { return age; }
	public double getHeight() { return height; }
	public double getWeight() { return weight; }

	//Getters
	public void setName(String name) { this.name = name; }
	public void setGender(String gender) { this.gender = gender; }
	public void setAge(int age) { this.age = age; }
	public void setHeight(double height) { this.height = height; }
	public void setWeight(double weight) { this.weight = weight; }
	
	//Support
	public String toString() {
		return "Name\t:  " + name + "\nGender\t:  " + gender + "\nAge\t:  " + age + "\nHeight\t:  " + height + "\nWeight\t:  " + weight;
	}
	public boolean equals(Object obj) {
		if (obj instanceof Person) {
			Person p = (Person) obj;
			return (this.name.equals(p.getName())) && (this.gender.equals(p.getGender())) && ((this.age == p.getAge())) && (this.height == p.getHeight()) && (this.weight == p.getWeight());
		}
		return false;
	}
}
