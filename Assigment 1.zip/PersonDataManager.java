import java.io.*;

public class PersonDataManager {
	//data-fields
	private static Person[] people;
	private static int size; //An indicator of the current amount of Person in the people array
	
	//Scanning CSV File Part
	public static void buildFromFile(String location) throws IllegalArgumentException {
        String line = "";
        location = reForm(location);
		try {
			//Counts the number rows first to set the size of the Person Array and store it
        	BufferedReader brSize = new BufferedReader(new FileReader(location));
        	line = brSize.readLine();
        	int length = 0;
        	while((line = brSize.readLine()) != null && !(line.equals(""))) {
        		length++;
        	}
        	brSize.close();
        	size = length;
        	
        	//Implements PersonDataManger - Scans the CSV file and store it in the Person Array in PersonDataManger Class
        	BufferedReader br = new BufferedReader(new FileReader(location));
        	line = br.readLine();
        	people = new Person[length];
        	int i = 0;
        	while((line = br.readLine()) != null && !(line.equals(""))) {
        		String[] values = line.split(",");
            	Person a = new Person(reForm(values[0]), reForm(values[1]), Integer.parseInt(reForm(values[2])), Double.parseDouble(reForm(values[3])), Double.parseDouble(reForm(values[4])));
            	people[i] = a;
            	i++;
        	}
        	br.close();
        	
        } catch (Exception e) { 
        	throw new IllegalArgumentException(); //Throws an IllegalArgumentException if something is wrong with the CSV file or the argument is improperly given
        }
	}
	private static String reForm(String s) { //This is an extra method to help "clean" the data in the CSV to be readable to the buildFromFile method
		//For some reason when reading the given CSV file, there appears to be String values with extra spaces in them thus this method fixes it
		//This is also use to handle some argument errors based on the users input Ex: If they added quotation marks around the path address 
		if (s.indexOf("\"") >= 0) return s.substring(s.indexOf("\"")+1, s.lastIndexOf("\""));
		else if (s.indexOf(" ")>=0) return s.substring(s.lastIndexOf(" ")+1);
		else return s;
	}
	
	//Saving CSV File
	public static void saveCSV(String path) {
		//As the name implies it save Data Structure to a CSV file.
		try {
			path = reForm(path);
			FileWriter fw = new FileWriter(path, false);
			BufferedWriter bw = new BufferedWriter(fw);
			PrintWriter pw = new PrintWriter(bw);
			pw.println("Name,Sex,Age,Height (in),Weight (lbs)");
			for(int i = 0; i < size; i++) {
				pw.println(people[i].getName()+","+people[i].getGender()+","+people[i].getAge()+","+people[i].getHeight()+","+people[i].getWeight());
			}
			pw.flush();
			pw.close();
			System.out.println("A file named " + path.substring(path.lastIndexOf("\\")+1) + " has been created!"); //Tells the user their named .csv file was saved
		} catch (Exception e) {
			System.out.println("The file was unable to be saved");
		}
	}
	
	//Adding Part
	public static void addPerson(Person newPerson) throws PersonAlreadyExistsException{
        for (int i = 0; i < size; i++) {
        	//Compares the name of each person with the new person to determine which name comes alphabetically afterwards
        	if ((people[i].getName().toUpperCase()).compareTo(newPerson.getName().toUpperCase()) >= 0 || i == size-1) { //This also takes into account with casing in the names
        		if (people[i].equals(newPerson)) { throw new PersonAlreadyExistsException(newPerson); }
        		if (size == people.length) { ensureCapacity(size*2+1); } //If the size of the array can't fit anymore new person, then it enlarges it
        		System.arraycopy(people, i, people, i+1, size-(i)); //Shift the list of persons after the new person upward by 1 in the array
        		System.out.println(newPerson.getName() + " has been added to the list!"); 
        		people[i] = newPerson; //Adds in the new person
        		size+=1; 
        		break;
        	}
        }
	}
	private static void ensureCapacity(int minimumCapacity) { //Another Helper method to help increase capacity of the people array when needed
        if (people.length < minimumCapacity) {
             Person[] biggerArray = new Person[minimumCapacity];
             System.arraycopy(people, 0, biggerArray, 0, size);
             people = biggerArray;
        }
	}

	//Getting Part
	public static void getPerson(String name) throws PersonDoesNotExistsException {
		boolean founded = false; //Determines if the person the user was looking for was founded or not
		for(int i = 0; i < size; i++) {
			if((name.toUpperCase()).equals((people[i].getName()).toUpperCase())) { //Checks the names of the each person in the people array while ingoring their cases
				Person p = people[i]; 
				String fullGender; 
				//Used to help write out "Male" for M and "Female" for F in the output
				if (people[i].getGender().equals("M")) fullGender = "male";
				else fullGender = "female";
				//Output
				System.out.format("%s is a %d year old %s who is %d feet and %d inches tall and weighs %.1f pounds.%n",
						p.getName(), p.getAge(), fullGender, ((int)p.getHeight())/(12), ((int)p.getHeight())%(12), p.getWeight());
				founded = true;
				break;
			}
		}
		if(!founded) throw new PersonDoesNotExistsException(name);
	}
	
	//Removing Part
	public static void removePerson(String name) throws PersonDoesNotExistsException {
		boolean founded = false; //Determines if the person the user was looking for was founded or not
		for(int i = 0; i < size; i++) {
			if((name.toUpperCase()).equals((people[i].getName()).toUpperCase())) { //Checks the names of the each person in the people array while ingoring their cases
				System.out.println(people[i].getName() + " has been removed!"); //Tells user the person been removed
				System.arraycopy(people, i+1, people, i, (size-1)-i); //Shift the list of persons in the people array down by 1
				size-=1;
				people[size] = null; //Removes the last person in the array since they've already probably been copied
				founded = true;
				break;
			}
		}
		if(!founded) throw new PersonDoesNotExistsException(name);
	}
	
	//Display Table
	public static void displayTable() { //Prints out a neat formatted table of the contents in the people array
		System.out.format("| %-15s| %-15s| %-15s| %-15s| %-15s|%n", "Name", "Gender", "Age", "Height", "Weight");
		System.out.println("======================================================================================");
		for (int i = 0; i < size; i++) { //Traverse through the people array to get each person in it to print its content out.
			System.out.format("| %-15s| %-15s| %-15d| %-15s| %-15s|%n", 
					people[i].getName(), people[i].getGender(), people[i].getAge(), 
					((int)people[i].getHeight())/(12) + " ft " + ((int)people[i].getHeight())%(12) + " in", people[i].getWeight() + " lbs");
		}
	}
}
