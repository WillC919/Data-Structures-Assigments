@SuppressWarnings("serial")
public class PersonDoesNotExistsException extends Exception {
	public PersonDoesNotExistsException(String s) {
		super(s + " does not exist in this list");
	}
}
