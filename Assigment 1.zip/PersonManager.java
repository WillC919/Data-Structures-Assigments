import java.util.InputMismatchException;
import java.util.Scanner;
public class PersonManager {
	public static void main(String[] args){
		// TODO Auto-generated method stub
		interativePanel();
	}
	public static void interativePanel() {
		boolean active = true; //The indicator whether to keep the program running
		boolean continueInput = true; //Used to continue a do-while loop if a proper input is not met
		System.out.println("Starting...");
		try {
			while (active) {
				System.out.println("Menu:\n"
						+ "\t(I) � Import from File\r\n" 
						+ "\t(A) � Add Person\n" 
						+ "\t(R) � Remove Person\n" 
						+ "\t(G) � Get Information on Person\n" 
						+ "\t(P) � Print Table\n" 
						+ "\t(S) � Save to File\n" 
						+ "\t(Q) � Quit\n" 
						+ "------------------------------------------------------------");
				System.out.println("Please select an option: ");
				Scanner input = new Scanner(System.in);
				String key = input.next().toUpperCase(); //.toUpperCase() Removes case sensitivity 
				String nameKey;
				
				//Import "function"
				if (key.equals("I") || key.equals("(I)")) {
					System.out.println("Please enter a location: ");
					
					do {
						try {
							String importLoc = input.next();
							PersonDataManager.buildFromFile(importLoc); 
							continueInput = false; //Ends while loop
						} catch (IllegalArgumentException e) { //Catches an error in their input
							System.out.println("The input you entered is incorrect or the CSV file is not applicable. Please try again! ");
							input.nextLine(); //Ask the user the input again
						}
					} while(continueInput); //Repeats the loop till it its imported properly
					
					continueInput = true; //Resets the value for repeating while loops
				
				//Add "function"
				} else if (key.equals("A") || key.equals("(A)")) { 
					//Input Variables
					int ageKey = 0;
					String genderKey = null;
					double heightKey = 0, weightKey = 0; 
					
					System.out.println("Please enter the name of the person: ");
					nameKey = input.next();
					
					System.out.println("Please enter the age: ");
					do {
						try {
							ageKey = input.nextInt(); 
							continueInput = false; //Ends while loop
						} catch (InputMismatchException e) { //Catches an error in their input
							System.out.println("The input you entered is incorrect. Please try again!");
			                input.nextLine(); //Ask the user the input again
						}
					} while (continueInput); //Repeats the loop till the input is done properly
					
					continueInput = true; //Resets the value for repeating while loops
					System.out.println("Please enter the gender (M or F): ");
					do {
						try {
							genderKey = input.next().toUpperCase();
							if (!genderKey.equals("M") && !genderKey.equals("F")) throw new InputMismatchException();
							continueInput = false; //Ends while loop
						} catch (InputMismatchException e) {
							System.out.println("The input you entered is incorrect. Please try again!");
			                input.nextLine(); //Ask the user the input again
						}
					} while (continueInput); //Repeats the loop till the input is done properly
					
					continueInput = true; //Resets the value for repeating while loops
					System.out.println("Please enter the height (in inches): ");
					do {
						try {
							heightKey = input.nextInt(); 
							continueInput = false; //Ends while loop
						} catch (InputMismatchException e) {
							System.out.println("The input you entered is incorrect. Please try again!");
			                input.nextLine(); //Ask the user the input again
						}
					} while (continueInput); //Repeats the loop till the input is done properly
					
					continueInput = true;
					System.out.println("Please enter the weight (in lbs): ");
					do {
						try {
							weightKey = input.nextInt();
							continueInput = false; //Ends while loop
						} catch (InputMismatchException e) {
							System.out.println("The input you entered is incorrect. Please try again!");
			                input.nextLine(); //Ask the user the input again
						} 
					} while (continueInput); //Repeats the loop till the input is done properly
					continueInput = true;
					try {
						PersonDataManager.addPerson(new Person(nameKey, genderKey, ageKey, heightKey, weightKey));
					} catch(PersonAlreadyExistsException e) { //Catches the PersonAlreadyExistsException in order to stop termination of the program
						System.out.println("Unable to add " + nameKey + " because they already exist"); 
					}
				//Remove "function"	
				} else if (key.equals("R") || key.equals("(R)")) {
					System.out.println("Please enter the name of the person: ");
					nameKey = input.next();
					try {
						PersonDataManager.removePerson(nameKey);
					} catch(PersonDoesNotExistsException e) { //Catches the PersonDoesNotExistsException in order to stop termination of the program
						System.out.println("Unable to remove " + nameKey + " because they do not exist");
					}
				
				//Get "function"
				} else if (key.equals("G") || key.equals("(G)")) { 
					System.out.println("Please enter the name of the person: ");
					nameKey = input.next();
					try {
						PersonDataManager.getPerson(nameKey);
					} catch (PersonDoesNotExistsException e) { //Catches the PersonDoesNotExistsException in order to stop termination of the program
						System.out.println("Unable to get " + nameKey + "'s info because they do not exist");
					}
					
				//Print Table "function"	
				} else if (key.equals("P") || key.equals("(P)")) {
					PersonDataManager.displayTable();
				
				//Save "function"	
				} else if (key.equals("S") || key.equals("(S)")) {
					System.out.println("Please select a name for the file: ");
					String pathKey = input.next();
					PersonDataManager.saveCSV(pathKey);
				
				//Quit "function"
				} else if (key.equals("Q") || key.equals("(Q)")) {
					System.out.println("Sorry to see you go!");
					active = false;
				} else System.out.println("The input you entered is incorrect. Please try again!");
			}
		} catch (Exception e) { //Catches any error that occurs
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
