@SuppressWarnings("serial")
public class PersonAlreadyExistsException extends Exception {	
	public PersonAlreadyExistsException(Person p) {
		super(p.getName() + " is already in the list");
	}
}
