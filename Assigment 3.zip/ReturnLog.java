public class ReturnLog {
	//Data field
	private long ISBN, userID;
	private Date returnDate;
	private ReturnLog nextLog;
	
	//Constructor
	public ReturnLog() {
		ISBN = -1;
		userID = -1;
		returnDate = new Date();
		nextLog = null;
	}
	public ReturnLog(long ISBN, long userID, Date returnDate) throws InvalidISBNException, InvalidUserIDException {
		if (!BookRepository.validISBNCheck(ISBN)) throw new InvalidISBNException();
		if (!BookRepository.validUserIDCheck(userID)) throw new InvalidUserIDException();
		this.ISBN = ISBN;
		this.userID = userID;
		this.returnDate = returnDate;
		this.nextLog = null;
	}
	
	//Getters
	public long getISBN() { return ISBN; }
	public long getUserID() { return userID; }
	public Date getReturnDate() { return returnDate; }
	public ReturnLog getNextLog() { return nextLog; }
	
	//Setters
	public void setISBN(long ISBN) { this.ISBN = ISBN; }
	public void setUserID(long userID) { this.userID = userID; }
	public void setReturnDate(Date returnDate) { this.returnDate = returnDate; }
	public void setNextLog(ReturnLog nextLog) { this.nextLog = nextLog; }
	
}
