@SuppressWarnings("serial")
public class InvalidISBNException extends Exception {
	public InvalidISBNException() {
		super("The specified ISBN does not exisit in our shelves");
	}
}
