public class Book {
	enum Condition { NEW, GOOD, BAD, REPLACE }
	//Data field
	private String name, author, genre;
	private Condition bookCondition;
	private long ISBN, checkOutUserID;
	private int yearPublished;
	private boolean checkedOut;
	private Date dueDate, checkOutDate;
	private Book nextBook;
	
	
	
	//Constructor
	public Book(){
		ISBN = -1;
		name = null;
		author = null;
		genre = null;
		bookCondition = null;
		yearPublished = -1;
		checkedOut = false;
		checkOutUserID = -1;
		checkOutDate = null;
		nextBook = null;
	}
	public Book(long ISBN, String name, String author, String genre, int yearPublished, Condition bookCondition) {
		this.ISBN = ISBN;
		this.name = name;
		this.author = author;
		this.genre = genre;
		this.bookCondition = bookCondition;
		this.yearPublished = yearPublished;
		checkedOut = false;
		checkOutUserID = -1;
		checkOutDate = null;
		nextBook = null;
	}
	
	//Helper Method
	public String toString() {
		String nb = "N/A", cod = "N/A", cou = "N/A";
		if (nextBook != null) nb = nextBook.getName();
		if (checkOutDate != null) cod = checkOutDate.toString();
		if (checkOutUserID != -1) cou = "" + checkOutUserID;
		return "Title:\t\t\t" + name + "\nAuthor:\t\t\t" + author + "\nGenre:\t\t\t" + genre + "\nISBN:\t\t\t" + ISBN + "\nYear Published:\t\t" + yearPublished + "\nChecked Out:\t\t" 
				+ checkedOut + "\nCheck Out User ID\t" + cou + "\ncheckOutDate\t\t" + cod + "\nNext Book ISBN\t\t" + nb;
	}
	
	//Getters
	public long getISBN() { return ISBN; }
	public String getName() { return name; }
	public String getAuthor() { return author; }
	public String getGenre() { return genre; }
	public int getYearPublished() { return yearPublished; }
	public Condition getCondition() { return bookCondition; }
	public Book getNextBook() { return nextBook; }
	public boolean getCheckedOut() { return checkedOut; }
	public Date getDueDate() { return dueDate; }
	public long getCheckOutUserID() { return checkOutUserID; }
	
	//Setters
	public void setNextBook(Book nextBook) { this.nextBook = nextBook; }
	public void setCheckedOut(boolean status) { checkedOut = status; }
	public void setCheckOutUserID(long checkOutUserID) { this.checkOutUserID = checkOutUserID; }
	public void setDueDate(Date dueDate) { if (checkedOut == true) this.dueDate = dueDate; }
	public void setCheckOutDate(Date checkOutDate) { this.checkOutDate = checkOutDate; }

}
