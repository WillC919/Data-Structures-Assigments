import java.util.InputMismatchException;
import java.util.Scanner;

public class LibraryManager {

	public static void main(String[] args) throws BookAlreadyExistsException, InvalidISBNException, IllegalArgumentException, InvalidUserIDException, BookAlreadyCheckedOutException {
		// TODO Auto-generated method stub
		BookRepository library = new BookRepository();
		ReturnStack checkInStack = new ReturnStack(library);
		
		libraryInterface(library, checkInStack);
	}
	//The interactive method
	public static void libraryInterface(BookRepository library, ReturnStack checkInStack) {
		boolean active = true, innerActive = true; //The indicator whether to keep the program running
		long isbnKey = -1, userIDKey = -1;
		int shelfKey = -1, yearKey = -1;
		String nameKey = "", authorKey = "", genreKey = "", dateKey = "", criteriaKey = "", onTime ="";
		Date newDateKey = new Date();
		Book.Condition conditionKey = null;
		
		System.out.println("Starting...");
		try {
			while(active) {
				System.out.println("\nMenu:\n\n"
							+ "\t(B) � Manage Book Repository\n"
									+ "\t\t(C) � Checkout Book\n"
									+ "\t\t(N) � Add New Book\n"
									+ "\t\t(R) � Remove Book\n"
									+ "\t\t(P) � Print Repository\n"
									+ "\t\t(S) � Sort Shelf:\n"
										+ "\t\t\t(I) � ISBN Number\n"
										+ "\t\t\t(N) � Name\n"
										+ "\t\t\t(A) � Author\n"
										+ "\t\t\t(G) � Genre\n"
										+ "\t\t\t(Y) � Year\n"
										+ "\t\t\t(C) � Condition\n" 
							+ "\t(R) � Manage Return Stack\n"
									+ "\t\t(R) � Return Book\n"
									+ "\t\t(S) � See Last Return\n"
									+ "\t\t(C) � Check In Last Return\n"
									+ "\t\t(P) � Print Return Stack\n"
							+ "\t(Q) � Quit\n" 
							+ "------------------------------------------------------------");
				System.out.println("Please select what to manage: ");
				Scanner input = new Scanner(System.in);
				String key = input.next().toUpperCase(), keyB, keyC = null; //.toUpperCase() Removes case sensitivity
				
				if (key.equals("B") || key.equals("(B)")) {
					System.out.println("Please select an option: ");
					keyB = input.next().toUpperCase();
					
					if (keyB.equals("C") || keyB.equals("(C)")) {
						do {
							try { 
								System.out.println("Please provide a library user ID:");
								userIDKey = input.nextLong();
								if (!BookRepository.validUserIDCheck(userIDKey)) throw new InputMismatchException(); //Checks the validity of the user ID
								innerActive = false;
							} catch (InputMismatchException e) {
								System.out.println("That is not a vaild number! Please try again:");
								input.nextLine();
							}
						} while(innerActive);
						innerActive = true;
						do {
							try { 
								System.out.println("Please provide an ISBN number:");
								isbnKey = input.nextLong();
								if (!BookRepository.validISBNCheck(isbnKey)) throw new InputMismatchException(); //Checks the validity of the ISBN
								innerActive = false;
							} catch (InputMismatchException e) {
								System.out.println("That is not a vaild number! Please try again:");
								input.nextLine();
							}
						} while(innerActive);
						innerActive = true;
						do {
							try { 
								System.out.println("Please provide a due date:");
								dateKey = input.next();
								newDateKey = new Date(dateKey); //Reads and checks the validity of this date
								innerActive = false;
							} catch (IllegalArgumentException e) {
								System.out.println("That is not a vaild Date! Please try again:");
								input.nextLine();
							}
						} while(innerActive);
						innerActive = true;
						
						try { 
							library.checkOutBook(isbnKey, userIDKey, newDateKey);
							System.out.println(library.findBook(isbnKey).getName() + " has been checked out by " + userIDKey + " and must be returned by " + newDateKey.toString());
						} catch (InvalidISBNException e) {
							System.out.println("The given ISBN was not a vaild ISBN!");
						} catch (InvalidUserIDException e) {
							System.out.println("The given ID is not a vaild user ID!");
						} catch (BookAlreadyCheckedOutException e) {
							System.out.println("Book has already been checked out!");
						} 
						
					} else if (keyB.equals("N") || keyB.equals("(N)")) { //Add Book Function
						try {
							do {
								try { 
									System.out.println("Please provide an ISBN number: ");
									isbnKey = input.nextLong();
									if (!BookRepository.validISBNCheck(isbnKey)) throw new InputMismatchException();
									innerActive = false;
								} catch (InputMismatchException e) {
									System.out.println("That is not a vaild ISBN! Please try again: ");
									input.nextLine();
								}
							} while (innerActive);
							innerActive = true;
							System.out.println("Please provide a name: ");
							nameKey = input.next() + input.nextLine(); // + input.nextLine() is needed to read spaces in the console apparently			
							System.out.println("Please provide an author: ");
							authorKey = input.next() + input.nextLine();
							System.out.println("Please provide a genre: ");
							genreKey = input.next() + input.nextLine();
							do {
								try { 
									System.out.println("Please provide a publishing year: ");
									yearKey = input.nextInt();
									innerActive = false;
								} catch (InputMismatchException e) {
									System.out.println("That is not a publishing year! Please try again: ");
									input.nextLine();
								}
							} while (innerActive);
							innerActive = true;
							do {
								try { 
									System.out.println("Please provide a condition:");
									conditionKey = Book.Condition.valueOf(input.next().toUpperCase());
									innerActive = false;
								} catch (IllegalArgumentException e) {
									System.out.println("That is not a vaild Condition! Please try again:");
									input.nextLine();
								}
							} while (innerActive);
							innerActive = true;
							
							library.addBook(isbnKey, nameKey, authorKey, genreKey, yearKey, conditionKey);
							System.out.println("Loading...\n" +  nameKey + " has been successfully added to the book repository!");
						} catch (BookAlreadyExistsException e) {
							System.out.println("This book already exist in our Book Repository");
						}
					} else if (keyB.equals("R") || keyB.equals("(R)")) {
						try {
							do {
								try { 
									System.out.println("Please provide an ISBN number: ");
									isbnKey = input.nextLong();
									nameKey = library.findBook(isbnKey).getName();
									library.removeBook(isbnKey);
									innerActive = false;
									System.out.println("Loading...\n" + nameKey + " has been successfully added to the book repository!");
								} catch (InputMismatchException e) {
									System.out.println("That is not a vaild ISBN! Please try again: ");
									input.nextLine();
								} catch (InvalidISBNException e) {
									System.out.println("That is not a vaild ISBN! Please try again: ");
									input.nextLine();
								}
							} while (innerActive);
							innerActive = true;
						} catch (BookDoesNotExistException e) {
							System.out.println("This book doesn't exisit in our Book Repository");
						} 
					} else if (keyB.equals("P") || keyB.equals("(P)")) {
						do {
							try {
								System.out.println("Please select a shelf: ");
								shelfKey = input.nextInt();
								if (shelfKey > 9 || shelfKey < 0) throw new InputMismatchException();
								else innerActive = false;
							} catch (InputMismatchException e) {
								System.out.println("That is not a vaild Shelf Number! Please try again: ");
								input.nextLine();
							}
						} while (innerActive);
						innerActive = true;
						
						library.displayShelfTable(shelfKey);
					} else if (keyB.equals("S") || keyB.equals("(S)")) {
						do {
							try {
								System.out.println("Please select a shelf: ");
								shelfKey = input.nextInt();
								if (shelfKey > 9 || shelfKey < 0) throw new InputMismatchException();
								else innerActive = false;
							} catch(InputMismatchException e) {
								System.out.println("That is not a vaild shelf number! Please try again: ");
								input.nextLine();
							}
						} while (innerActive);
						innerActive = true;
						do {
							try {
								System.out.println("Please select a sorting criteria: ");
								keyC = input.next().toUpperCase();
								if (!(keyC.equals("I") || keyC.equals("(I)") || keyC.equals("N") || keyC.equals("(N)") 
										|| keyC.equals("A") || keyC.equals("(A)") || keyC.equals("G") || keyC.equals("(G)") 
										|| keyC.equals("Y") || keyC.equals("(Y)") || keyC.equals("C") || keyC.equals("(C)"))) throw new InputMismatchException();
								else innerActive = false;
							} catch(InputMismatchException e) {
								System.out.println("That is not a vaild sorting criteria! Please try again: ");
								input.nextLine();
							}
						} while (innerActive);
						innerActive = true;
						
						if (keyC.equals("I") || keyC.equals("(I)")) {
							library.sortShelf(shelfKey, "ISBN");
							criteriaKey = "ISBN";
						} else if (keyC.equals("N") || keyC.equals("(N)")) {
							library.sortShelf(shelfKey, "NAME");
							criteriaKey = "name";
						} else if (keyC.equals("A") || keyC.equals("(A)")) {
							library.sortShelf(shelfKey, "AUTHOR");
							criteriaKey = "author";
						} else if (keyC.equals("G") || keyC.equals("(G)")) {
							library.sortShelf(shelfKey, "GENRE");
							criteriaKey = "genre";
						} else if (keyC.equals("Y") || keyC.equals("(Y)")) {
							library.sortShelf(shelfKey, "YEAR");
							criteriaKey = "year";
						} else if (keyC.equals("C") || keyC.equals("(C)")) {
							library.sortShelf(shelfKey, "CONDITION");
							criteriaKey = "condition";
						} 
						
						System.out.println("Shelf " + shelfKey + " has been sorted by " + criteriaKey);
					} else System.out.println("The input you entered is incorrect");
					
				} else if (key.equals("R") || key.equals("(R)")) {
					System.out.println("Please select an option: ");
					keyB = input.next().toUpperCase();
					
					if (keyB.equals("R") || keyB.equals("(R)")) {
						do {
							try {
								System.out.println("Please provide the ISBN of the book you�re returning: ");
								isbnKey = input.nextLong();
								if (!BookRepository.validISBNCheck(isbnKey)) throw new InputMismatchException(); //Checks the validity of the ISBN
								innerActive = false;
							} catch(InputMismatchException e) {
								System.out.println("That is not a vaild ISBN! Please try again: ");
								input.nextLine();
							}
						} while (innerActive);
						innerActive = true;
						do {
							try {
								System.out.println("Please your Library UserID: ");
								userIDKey = input.nextLong();
								if (!BookRepository.validUserIDCheck(userIDKey)) throw new InputMismatchException(); //Checks the validity of the user ID
								innerActive = false;
							} catch(InputMismatchException e) {
								System.out.println("That is not a vaild User ID! Please try again: ");
								input.nextLine();
							}
						} while (innerActive);
						innerActive = true;
						do {
							try {
								System.out.println("Please your current date: ");
								dateKey = input.next();
								newDateKey = new Date(dateKey);
								if (checkInStack.pushLog(isbnKey, userIDKey, newDateKey)) onTime = "returned on time!";
								else {
									onTime = "returned LATE! Checking everything in...";
									checkInStack.popAllLogs();
								}
								System.out.println(library.findBook(isbnKey).getName() + " has been " + onTime);
								innerActive = false;
							} catch (IllegalArgumentException e) {
								System.out.println("The given return date is not a vaild date! Please try again: ");
								input.nextLine();
							} catch (InvalidISBNException e) {
								System.out.println("The given ISBN is not listed in our Book Repository!");
								innerActive = false;
							} catch (BookCheckedOutBySomeoneElseException e) {
								System.out.println("The given user ID is not a vaild holder of the given Book!");
								innerActive = false;
							} catch (BookNotCheckedOutException e) {
								System.out.println("The given book was never checked out in the first place!");
								innerActive = false;
							}
						} while(innerActive);
					} else if (keyB.equals("S") || keyB.equals("(S)")) {
						System.out.println(library.findBook(checkInStack.peak().getISBN()).getName() + " is the next book to be checked in.");
					} else if (keyB.equals("C") || keyB.equals("(C)")) {
						System.out.println(library.findBook(checkInStack.popLog().getISBN()).getName() + " has been checked in!");
					} else if (keyB.equals("P") || keyB.equals("(P)")) {
						checkInStack.displayStack();
					} else System.out.println("The input you entered is incorrect");
				} else if (key.equals("Q") || key.equals("(Q)")) {
					System.out.println("Sorry to see you go!");
					active = false;
				} else System.out.println("The input you entered is incorrect. Please try again!");
			}
		} catch (Exception e) { //Catches any error that occurs
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
