public class Shelf {
	enum SortCriteria { ISBN, NAME, AUTHOR, GENRE, YEAR, CONDITION }
	//Data field
	private Book headBook, tailBook;
	private SortCriteria shelfSortCriteria;
	private int length;
	
	//Constructor 
	public Shelf() {
		headBook = null;
		tailBook = null;
		shelfSortCriteria = SortCriteria.ISBN;
		length = 0;	
	}
	
	//Getters
	public Book getHeadBook() { return headBook; }
	public int getLength() { return length; }
	
	//Methods
	public void addBook(Book addedBook) throws BookAlreadyExistsException {
		if (headBook == null) { //Checks if linked list is empty
			headBook = addedBook;
			tailBook = headBook;
			length++;
		} else { //else tries to add the book normally
			Book checkBook = headBook, prevTarget = null, target = headBook, nextTarget = target.getNextBook();
			long newBookISBN = addedBook.getISBN();
			
			while (checkBook != null) {  //Checks to see any books with the same ISBN
				if(newBookISBN == checkBook.getISBN()) throw new BookAlreadyExistsException();
				checkBook = checkBook.getNextBook();
			}
			
			boolean measure = true;
			String newBookName = addedBook.getName(), newBookAuthor = addedBook.getAuthor(), newBookGenre = addedBook.getGenre();
			int newBookYearPub = addedBook.getYearPublished();
			Book.Condition newBookCondition = addedBook.getCondition();
			
			//Determines which criteria to measure/compare by
			switch (shelfSortCriteria) {
			case ISBN: measure = newBookISBN < target.getISBN(); break;
			case NAME: measure = newBookName.compareTo(target.getName()) <= 0; break;
			case AUTHOR: measure = newBookAuthor.compareTo(target.getAuthor()) <= 0; break;
			case GENRE: measure = newBookGenre.compareTo(target.getGenre()) <= 0; break;
			case YEAR: measure = newBookYearPub < target.getYearPublished(); break;
			case CONDITION: measure = newBookCondition.ordinal() < target.getCondition().ordinal(); break;
			} 
			
			while (nextTarget != null) {
	    		if (measure) break; //Determines the location within the shelf to put the book in
	    		else {
	    			prevTarget = target;
	    			target = nextTarget;
		   			nextTarget = nextTarget.getNextBook();
		   			
		   			//Updates the target in measure
		   			switch (shelfSortCriteria) {
					case ISBN: measure = newBookISBN < target.getISBN(); break;
					case NAME: measure = newBookName.compareTo(target.getName()) <= 0; break;
					case AUTHOR: measure = newBookAuthor.compareTo(target.getAuthor()) <= 0; break;
					case GENRE: measure = newBookGenre.compareTo(target.getGenre()) <= 0; break;
					case YEAR: measure = newBookYearPub < target.getYearPublished(); break;
					case CONDITION: measure = newBookCondition.ordinal() < target.getCondition().ordinal(); break;
					} 
	   			}
	   		}
	    	
	   		if (prevTarget == null) { //Occurs when cursor is pointing at first and only element in linked list
	   			if (measure) { //Determines if it goes before to become the new head book
	   				addedBook.setNextBook(headBook);
		   			headBook = addedBook;
	   			} else { // else it goes after making it the new tail book
	   				headBook.setNextBook(addedBook);
	   				tailBook = addedBook;
	   			}
	   		} else if (nextTarget == null) { //occurs when cursor points at the end of the list
	   			if (measure) { //determines if it goes before
	   				prevTarget.setNextBook(addedBook);
	   	   			addedBook.setNextBook(target);
	   			} else { //else it becomes the new tail book
	   				tailBook.setNextBook(addedBook);
	   	   			tailBook = addedBook;
	   			}
	   		} else { //else proceeds normally
	   			prevTarget.setNextBook(addedBook);
	   			addedBook.setNextBook(target);
	   		}
	   		
	   		length++;
		}
	}
	public void removeBook(long removedISBN) throws BookDoesNotExistException {
		if (headBook == null) { //Checks if linked list is empty
			System.out.println("There is nothing to be removed on this shelf");
		} else if (removedISBN == headBook.getISBN()) { //Checks if item being removed is the head book
			headBook = headBook.getNextBook();
			length--;
		} else { // 
			Book target = headBook, nextTarget = target.getNextBook();
			boolean found = false;
			
			while (nextTarget != null && !found) {
				if (removedISBN == nextTarget.getISBN()) {
					target.setNextBook(nextTarget.getNextBook()); //removal of the given book
					length--;
					found = true; //ends the while loop to save time
				} else { //advances the cursor 
					target = nextTarget;
					nextTarget = nextTarget.getNextBook(); 
				}
			}
			if(!found) throw new BookDoesNotExistException(); //When no match is found during the process, the exception is thrown
			else if(target.getNextBook() == null) tailBook = target; //else the last target before loop ends (known as tail book) is set to be the new tail book
		}
	}
	public void sort(SortCriteria sortCriteria) throws InvalidSortCriteraException {
		shelfSortCriteria = sortCriteria;
		Boolean measure = true;
		Book prevTarget = null, target = headBook, nextTarget = headBook.getNextBook();
		
		//Determines which criteria to measure/compare by
		switch(sortCriteria) {
	    case ISBN: measure = target.getISBN() > nextTarget.getISBN(); break;
	    case NAME: measure = (target.getName()).compareTo(nextTarget.getName()) > 0; break;
	    case AUTHOR: measure = (target.getAuthor()).compareTo(nextTarget.getAuthor()) > 0; break;
	    case GENRE: measure = (target.getGenre()).compareTo(nextTarget.getGenre()) > 0; break;
	    case YEAR: measure = target.getYearPublished() > nextTarget.getYearPublished(); break;
	    case CONDITION: measure = target.getCondition().ordinal() > nextTarget.getCondition().ordinal(); break;
	    default: throw new InvalidSortCriteraException();
		}
		//The Bubble sorting section
		for (int i = 0; i < length; i++) {
			prevTarget = null; target = headBook; nextTarget = headBook.getNextBook();
			while (nextTarget != null) {
				//Updates the measure condition
				switch(sortCriteria) {
			    case ISBN: measure = target.getISBN() > nextTarget.getISBN(); break;
			    case NAME: measure = (target.getName()).compareTo(nextTarget.getName()) > 0; break;
			    case AUTHOR: measure = (target.getAuthor()).compareTo(nextTarget.getAuthor()) > 0; break;
			    case GENRE: measure = (target.getGenre()).compareTo(nextTarget.getGenre()) > 0; break;
			    case YEAR: measure = target.getYearPublished() > nextTarget.getYearPublished(); break;
			    case CONDITION: measure = target.getCondition().ordinal() > nextTarget.getCondition().ordinal(); break;
			    default: throw new InvalidSortCriteraException();
				}
				//The occurrence bubble sorting when condition is met
				if(measure) { 
					//Switching links
					target.setNextBook(nextTarget.getNextBook());
					nextTarget.setNextBook(target);
					if(prevTarget == null) headBook = nextTarget; //Ensures that the correct head book is being referenced
					else prevTarget.setNextBook(nextTarget);
					
					//Switching name reference
					Book temp = target;
					target = nextTarget;
					nextTarget = temp;
				}
				//Advancing the cursor
				prevTarget = target;
				target = nextTarget;
				nextTarget = nextTarget.getNextBook();
			}
		}
		tailBook = target; //Ensures that the correct tail book is being referenced 
	}
	
	//Helper Method
	public String toString() {
		String hb = "N/A", tb = "N/A";
		if (length > 0) { //Determines if values of null need to be replaced with N/A
			hb = headBook.getName();
			tb = tailBook.getName();
			
		}
		return "Head Book:\t" + hb + "\nTail Book:\t" + tb + "\nNo. of Books:\t" + length + "\nSorting Criteria:\t" + shelfSortCriteria;
	}
}
