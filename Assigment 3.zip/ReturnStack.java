public class ReturnStack {
	//Data field
	private ReturnLog topLog;
	private BookRepository bookRepoRef;
	
	//Constructor 
	public ReturnStack() {
		topLog = null;
		bookRepoRef = null;
	}
	public ReturnStack(BookRepository libarayAddress) { //Used a constructor to initialize a variable to store reference to BookRepository
		topLog = null;
		this.bookRepoRef = libarayAddress; //Didn't use the header of pushLog from the HW because popLog needed a reference to it as well
	}
	
	//Methods
	public boolean pushLog(long returnISBN, long returnUserID, Date returnDate) throws InvalidISBNException, InvalidReturnDateException, BookNotCheckedOutException, BookCheckedOutBySomeoneElseException, InvalidUserIDException {	
		Book keyBook = bookRepoRef.findBook(returnISBN); //Verifies and finds the book based on returnISBN
		if (!keyBook.getCheckedOut()) throw new BookNotCheckedOutException(); //Checks to see if the book was checked out or not
		if (returnUserID != keyBook.getCheckOutUserID()) throw new BookCheckedOutBySomeoneElseException(); //Verifies the holder of this book
		
		if(topLog == null) { //Checks first to see if its empty in order to properly execute certain task  
			topLog = new ReturnLog(returnISBN, returnUserID, returnDate);
		} else { //else proceeds normally
			ReturnLog newLog = new ReturnLog(returnISBN, returnUserID, returnDate);
			newLog.setNextLog(topLog);
			topLog = newLog;
		}
		
		if (Date.compare(returnDate, keyBook.getDueDate()) <= 0) return true; //If return date is not pass due date it returns true
		else return false; //else it'll return false if book is being returned in late
	}
	public ReturnLog popLog() throws EmptyStackException, InvalidISBNException {
		if (topLog == null) throw new EmptyStackException(); //Checks if stack is empty
		bookRepoRef.checkInBook(topLog.getISBN());
		ReturnLog poppedLog = topLog; //Saves topLog to return it later
		topLog = topLog.getNextLog(); //Makes the next log the new topLog while removing the old one
		return poppedLog;
	}
	
	//Helper Method
	public String toString() {
		return "Top Log Address:\t" + topLog + "\nBook Repository Address:\t" + bookRepoRef;
	}
	
	//Other Helpful Methods
	public ReturnLog peak() { //Returns the top log in the stack
		return topLog;
	}
	public void popAllLogs(){ //Pops all the logs in the stack
		while(topLog != null) {
			try { bookRepoRef.checkInBook(topLog.getISBN()); } catch (InvalidISBNException e) {}
			topLog = topLog.getNextLog(); //Makes the next log the new topLog while removing the old one
		}
	}
	public void displayStack() { //Prints out a neat formatted table of the contents of stack of logs
		ReturnLog cursorLog = topLog;
		String fullISBN = "", fullID = "";
		long currISBN, currUID;
		int n = 0, i = 0;
		
		System.out.format("| %-20s| %-20s| %-15s|%n", "ISBN", "UserID", "Return Date");
		System.out.println("==============================================================");
		while (cursorLog != null) { //traverse through the linked list of logs in the stack
			fullISBN = ""; fullID = "";
			n = 0; i = 0;
			currISBN = cursorLog.getISBN(); currUID = cursorLog.getUserID();
			if (currISBN == 0) n = 1; //To prevent a infinite for loop from occurring
			if (currUID == 0) i = 1; //To prevent a infinite for loop from occurring
			for (long k = currISBN + n; k < 1000000000000L; k*=10) fullISBN += "0";
			for (long k = currUID + i; k < 1000000000L; k*=10) fullID += "0";

			fullISBN += cursorLog.getISBN(); fullID += cursorLog.getUserID();
			
			System.out.format("| %-20s| %-20s| %-15s|%n", fullISBN, fullID, cursorLog.getReturnDate().toString());
			cursorLog = cursorLog.getNextLog();
		}
	}
	
	//Setter
	public void setBookRepository(BookRepository br) {
		bookRepoRef = br;
	}
}
