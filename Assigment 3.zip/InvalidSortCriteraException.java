@SuppressWarnings("serial")
public class InvalidSortCriteraException extends Exception {
	public InvalidSortCriteraException() {
		super("The specified sorting critera is a not valid critera");
	}
}
