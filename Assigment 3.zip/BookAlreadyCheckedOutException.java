@SuppressWarnings("serial")
public class BookAlreadyCheckedOutException extends Exception {
	public BookAlreadyCheckedOutException() {
		super("The specified Book has already been checked out");
	}
}
