@SuppressWarnings("serial")
public class BookAlreadyExistsException extends Exception {
	public BookAlreadyExistsException() {
		super("This specified book already exists in the shelf");
	}
}
