@SuppressWarnings("serial")
public class InvalidUserIDException extends Exception {
	public InvalidUserIDException() {
		super("The specified User ID is not valid ID");
	}
}
