@SuppressWarnings("serial")
public class BookCheckedOutBySomeoneElseException extends Exception {
	public BookCheckedOutBySomeoneElseException() {
		super("This book was already checked out by a different holder");
	}
}
