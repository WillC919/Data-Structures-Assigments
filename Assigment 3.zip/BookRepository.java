public class BookRepository {
	//Data field
	private Shelf[] shelves;
	
	//Constructor
	public BookRepository() {
		shelves = new Shelf[10];
		for (int i = 0; i < 10; i++) shelves[i] = new Shelf();
	}
	
	//Methods
	public void checkInBook(long checkedInISBN) throws InvalidISBNException {
		Book checkedBook = findBook(checkedInISBN);
		checkedBook.setCheckedOut(false);
	}
	public void checkOutBook(long checkedOutISBN, long checkOutUserID, Date dueDate) throws InvalidISBNException, InvalidUserIDException, BookAlreadyCheckedOutException {
		//Finds and checks the validity of the ISBN and User ID
		Book checkedBook = findBook(checkedOutISBN);
		if (checkedBook.getCheckedOut()) throw new BookAlreadyCheckedOutException();
		if (!validUserIDCheck(checkOutUserID)) throw new InvalidUserIDException();
		
		checkedBook.setCheckedOut(true);
		checkedBook.setCheckOutUserID(checkOutUserID);
		checkedBook.setDueDate(dueDate);
		checkedBook.setCheckOutDate(new Date());
	}
	
	public void addBook(long addISBN, String addName, String addAuthor, String addGenre, int addYear, Book.Condition addCondition) throws BookAlreadyExistsException, InvalidISBNException {
		if(!validISBNCheck(addISBN)) throw new InvalidISBNException();
		int shelfNum = (int) (addISBN/1000000000000L);
		shelves[shelfNum].addBook(new Book( addISBN, addName, addAuthor, addGenre, addYear, addCondition));
	}
	public void removeBook(long removeISBN) throws InvalidISBNException, BookDoesNotExistException{
		if (!validISBNCheck(removeISBN)) throw new InvalidISBNException();
		int shelfNum = (int) (removeISBN/1000000000000L);
		shelves[shelfNum].removeBook(removeISBN);
	}
	public void sortShelf(int shelfInd, String sortCriteria) throws InvalidSortCriteraException {
		shelves[shelfInd].sort(Shelf.SortCriteria.valueOf(sortCriteria.toUpperCase()));
	}
	
	//Other Helpful Methods
	public void displayShelfTable(int num) { //Prints out a neat formatted table of the contents of Books in a specified shelf
		Shelf s = shelves[num];
		System.out.format("| %-60s| %-15s| %-15s| %-25s|%n", "Name", "Checked Out", "Due Date", "Checkout UserID");
		System.out.println("============================================================================================================================");
		
		Book cursorBook = s.getHeadBook();
		String checkedOutStatus, dateDue, userID = "";
		long uID = 0;
		int n = 0;
		for (int i = 0; i < s.getLength(); i++) { //traverse through the linked list of lines
			if (cursorBook.getCheckedOut()) { //Used to determine the appropriate lines to print
				checkedOutStatus = "Y"; 
				dateDue = cursorBook.getDueDate().toString();
				userID = ""; //Resets the user ID to remove the "N/A"
				uID = cursorBook.getCheckOutUserID(); n = 0;
				if (uID == 0) n = 1; //To prevent a infinite for loop from occurring
				for (long k = uID + n; k < 1000000000L; k*=10) userID += "0"; //Adds the zeros to the leading numbers that are under 13 digits long
				userID += Long.toString(uID);
			} else {
				checkedOutStatus = "N";
				dateDue = "N/A";
				userID = "N/A";
			}
			System.out.format("| %-60s| %-15s| %-15s| %-25s|%n", cursorBook.getName(), checkedOutStatus, dateDue, userID);
			cursorBook = cursorBook.getNextBook();
		}
	}
	public Book findBook(long ISBN) throws InvalidISBNException { //Locates the book within the Book Repository based on the ISBN
		if (!validISBNCheck(ISBN)) throw new InvalidISBNException();
		int shelfNum = (int) (ISBN/1000000000000L); //Takes the first digit of the ISBN
		Book targetBook = shelves[shelfNum].getHeadBook();
		
		while(targetBook != null) {
			if (targetBook.getISBN() == ISBN) return targetBook;
			targetBook = targetBook.getNextBook();
		}
		throw new InvalidISBNException(); //Throws an exception if its unable to find any book the matche with the ISBN
	}
	public static boolean validISBNCheck(long ISBN) { //Checks the validity of the ISBN
		if (ISBN >= 0 && ISBN/1000000000000L < 10) return true;
		else return false;
	}
	public static boolean validUserIDCheck(long id) { //Checks the validity of the user ID
		if (id >= 0 && id/1000000000L < 10) return true;
		else return false;
	}
}
