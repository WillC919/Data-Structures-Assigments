@SuppressWarnings("serial")
public class BookDoesNotExistException extends Exception {
	public BookDoesNotExistException() {
		super("The specified book does not exists in our shelf");
	}
}
