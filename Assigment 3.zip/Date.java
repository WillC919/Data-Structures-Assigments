public class Date {
	//Data field
	private int day, month, year;
	
	//Constructor
	public Date() {
		day = 0;
		month = 0;
		year = 0;
	}
	public Date(int day, int month, int year) throws IllegalArgumentException {
		if (month < 1 || month > 12 || day < 1 || day > 31 || year < 1) throw new IllegalArgumentException(); //Checks if date is vaild type of date
		this.day = day;
		this.month = month;
		this.year = year;
	}
	public Date(String date) throws IllegalArgumentException {
		String[] time;
		if (date.indexOf("/") >= 0) { time = date.split("/"); }
		else if (date.indexOf("-") >= 0) { time = date.split("-"); }
		else throw new IllegalArgumentException();
		
		if (time.length != 3) throw new IllegalArgumentException();
		
		int d = Integer.parseInt(time[1]);
		int m = Integer.parseInt(time[0]);
		int y = Integer.parseInt(time[2]);
		
		if (m < 1 || m > 12 || d < 1 || d > 31 || y < 1) throw new IllegalArgumentException();
		
		day = d;
		month = m;
		year = y;
	}
	
	//Compare Method
	public static int compare(Date x, Date y) {
		if (x.getNumericalDate() == y.getNumericalDate()) return 0; 
		else if (x.getNumericalDate() < y.getNumericalDate()) return -1; //When x's date is before y's date it returns -1
		else return 1; //When x's date is after y date it returns -1
	}
	//Method that helps the Compare Method
	private int getNumericalDate() { //Returns the entire date of the book into a single numerical value in days
		return year*365 + month*31 + day; //This makes it easier for the compare method execute because its comparing less variables
	}

	public String toString() {
		String d = "", m = "", y = "";
		if (day < 10) d = "0";
		if (month < 10) m = "0";
		if (year < 100) for (int i = year; i < 1000; i*=10) y += "0";
		return m + month + "/" + d + day + "/" + y + year;
	}
	
	//Getters
	public int getDay() { return day; }
	public int getMonth() { return month; }
	public int getYear() { return year;} 
	
	//Setters
	public void setDay(int n) { day = n; }
	public void setMonth(int n) { month = n; }
	public void setYear(int n) { year = n;} 
}
