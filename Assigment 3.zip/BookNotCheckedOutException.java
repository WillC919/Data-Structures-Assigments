@SuppressWarnings("serial")
public class BookNotCheckedOutException extends Exception {
	public BookNotCheckedOutException() {
		super("The given book was never checked out");
	}
}
