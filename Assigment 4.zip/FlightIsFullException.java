public class FlightIsFullException extends Exception {
    public FlightIsFullException() {
        super("Flight has no seat available this passenger!");
    }
}
