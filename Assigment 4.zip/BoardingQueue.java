public class BoardingQueue {
    //Data-field
    private final Passenger[] passengerQueue; //This is a circular array
    private int front, rear, size;

    //Constructor
    public BoardingQueue() {
        passengerQueue = new Passenger[10];
        front = -1;
        rear = -1;
        size = 0;
    }

    //Queue Methods
    public void enqueuePassenger(Passenger newPass) throws NoRoomException {
        int capacity = passengerQueue.length;
        if (size == 0) {
            front = 0; rear = 0;
            passengerQueue[0] = newPass;
            size++;
        } else {
            if (size == capacity) { throw new NoRoomException(); }
            else {
                int position = front;
                boolean priorityFound = false; //Used to indicate if the current enqueueing passenger has any higher priority over the other passengers on the queue
                int passClassCur = newPass.getPassClass().ordinal(), passIDCur = newPass.getPassengerID(), passClassObv;

                for (int i = 0; i < size && !priorityFound; i++) {
                    passClassObv = passengerQueue[position].getPassClass().ordinal();
                    //Determines Class Status of passenger and its
                    if ((passClassCur < passClassObv) || (passClassCur == passClassObv && passIDCur < newPass.getPassengerID())) {

                            Passenger shiftPass = passengerQueue[position], prevPass;
                            passengerQueue[position] = newPass;
                            priorityFound = true;

                            for (int j = i; j < size; j++) { //Pushes back the entire passengers waiting behind a higher priority passenger
                                position = (position + 1) % capacity;
                                prevPass = passengerQueue[position];
                                passengerQueue[position] = shiftPass;
                                shiftPass = prevPass;
                            }

                            rear = (rear + 1) % capacity;
                    } else { position = (position + 1) % capacity; }
                }
                //If it has no higher priority, it'll be put in the last of the queue
                if (!priorityFound) {
                    rear = (rear+1) % capacity;
                    passengerQueue[rear] = newPass;
                }
                size++; //Updates the size
            }
        }
    }
    public Passenger dequeuePassenger() throws NoPassengerException {
        if (size == 0) throw new NoPassengerException(); //Checks if Queue is empty
        Passenger boardingPass = passengerQueue[front];
        passengerQueue[front] = null;
        if (size == 1) { //Execute the proper algorithm if there is only one passenger left on the queue
            front = -1; rear = -1;
            size = 0;
        } else { //else if it executes normally
            front = (front + 1) % 10;
            size--;
        }
        return boardingPass;
    }

    //Getters
    public int getSize() { return size; }
}
