public class Flight {
    //Data-field
    private String destination;
    private BoardingQueue boardQueue;
    private Passenger[] firstClass, businessClass, premiumEconomy, economy;
    private int minutesLeftBoarding, minutesLeftDeparting, firstClassInd, businessClassInd, premiumEconomyInd, economyInd, passengerCapacity;
    private boolean boarding;
    private boolean airForceStatus;

    //Constructor
    public Flight(String destination, boolean airForce1Status) {
        this.destination = destination;
        boardQueue = new BoardingQueue();
        airForceStatus = airForce1Status;
        boarding = true;

        firstClass = new Passenger[2];
        businessClass = new Passenger[3];
        premiumEconomy = new Passenger[4];
        economy = new Passenger[6];

        passengerCapacity = firstClass.length + businessClass.length + premiumEconomy.length + economy.length;

        firstClassInd = 0;
        businessClassInd = 0;
        premiumEconomyInd = 0;
        economyInd = 0;

        minutesLeftBoarding = 25;
        minutesLeftDeparting = 5;
    }

    //Methods
    public void addToFlight(Passenger boardedPass) throws FlightIsFullException {
        Passenger.TravelClass classStatus = boardedPass.getPassClass();

        if (classStatus == Passenger.TravelClass.FIRST) {
            if (firstClassInd < firstClass.length) {
                firstClass[firstClassInd] = boardedPass;
                boardedPass.setSeatType(Passenger.TravelClass.FIRST); //Updates their seat type, in which it'll differ from their class type depending on flight space
                firstClassInd++;
                return;
            } else { classStatus = Passenger.TravelClass.BUSINESS; }//downgrades current class seat if the current class seating is full
        }
        if (classStatus == Passenger.TravelClass.BUSINESS) {
            if (businessClassInd < businessClass.length) {
                businessClass[businessClassInd] = boardedPass;
                boardedPass.setSeatType(Passenger.TravelClass.BUSINESS);
                businessClassInd++;
                return;
            } else { classStatus = Passenger.TravelClass.PREMIUM_ECONOMY; }
        }
        if (classStatus == Passenger.TravelClass.PREMIUM_ECONOMY) {
            if (premiumEconomyInd < premiumEconomy.length) {
                premiumEconomy[premiumEconomyInd] = boardedPass;
                boardedPass.setSeatType(Passenger.TravelClass.PREMIUM_ECONOMY);
                premiumEconomyInd++;
                return;
            } else { classStatus = Passenger.TravelClass.ECONOMY; }
        }
        if (classStatus == Passenger.TravelClass.ECONOMY && economyInd < economy.length) {
            economy[economyInd] = boardedPass;
            boardedPass.setSeatType(Passenger.TravelClass.ECONOMY);
            economyInd++;
            return;
        } else throw new FlightIsFullException();
    }

    //Getters and Setters
    public int getMinutesLeftBoarding() { return minutesLeftBoarding; }
    public void setMinutesLeftBoarding(int minutesLeftBoarding) { this.minutesLeftBoarding = minutesLeftBoarding; }
    public int getMinutesLeftDeparting() { return minutesLeftDeparting; }
    public void setMinutesLeftDeparting(int minutesLeftDeparting) { this.minutesLeftDeparting = minutesLeftDeparting; }
    public boolean isBoarding() { return boarding; }
    public void setBoarding(boolean boarding) { this.boarding = boarding; }
    public String getDestination() { return destination; }
    public BoardingQueue getBoardQueue() { return boardQueue; }
    public int getTotalPassenger() { return firstClassInd + businessClassInd + premiumEconomyInd + economyInd; }
    public int getPassengerCapacity() { return passengerCapacity; }
    public boolean getAirForceStatus() { return airForceStatus; }

    //Helper Method
    public String toString() {
        return "First Class:\t" + firstClassInd + "/" + firstClass.length + " passengers\n"
                + "Business Class:\t" + businessClassInd + "/" + businessClass.length + " passengers\n"
                + "Premium Economy:\t" + premiumEconomyInd + "/" + premiumEconomy.length + " passengers\n"
                + "Economy:\t" + economyInd + "/" + economy.length + " passengers\n"
                + "Minutes Left Boarding:\t" + minutesLeftBoarding + " mins\n"
                + "Minutes Left Departing\t" + minutesLeftBoarding + " mins";

    }
    public void displayFlightTable() {
        System.out.println("Flight: RFK -> " + destination);
        System.out.format("   | %-30s| %-7s| %-15s|%n", "Seat Type", "ID", "Arrival Time");
        System.out.println("   ===========================================================");

        for (int i = 0; i < firstClassInd; i++)
            System.out.format("   | %-30s| %-7s| %-15s|%n", "First Class", firstClass[i].getPassengerID(), firstClass[i].getArrivalTime());
        for (int i = 0; i < businessClassInd; i++)
            System.out.format("   | %-30s| %-7s| %-15s|%n", "Business Class", businessClass[i].getPassengerID(), businessClass[i].getArrivalTime());
        for (int i = 0; i < premiumEconomyInd; i++)
            System.out.format("   | %-30s| %-7s| %-15s|%n", "Premium Economy", premiumEconomy[i].getPassengerID(), premiumEconomy[i].getArrivalTime());
        for (int i = 0; i < economyInd; i++)
            System.out.format("   | %-30s| %-7s| %-15s|%n", "Economy", economy[i].getPassengerID(), economy[i].getArrivalTime());
    }
}
