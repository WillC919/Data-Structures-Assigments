import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class FlightSimulator {
    public static void main (String [] args){
        Flight[] flightTerminals = new Flight[20];
        Random randomNumberGenerator = new Random();
        simulatorInterface(flightTerminals, randomNumberGenerator);
    }

    //Other Methods
    public static void simulatorInterface(Flight[] terminals, Random rng) {
        int airportCapacity = terminals.length, flightIndex, departingIndex, stopwatch = 0, flightID = 0;
        boolean statusOfAirForce1 = false, currentlyBoarding, covidPos = false;
        String events = "", eventsEQ = "", eventsDQ = "", boarding, departing;
        Flight[] finalDepartingFlights; Flight jetliner, airForce1 = null; BoardingQueue bq; Passenger keyPassenger;

        System.out.println("Welcome to RFK Private International Airport!\n");
        long seed = inputLoopLong("Enter a seed for this simulation: ", "That is not a valid seed! Please try again!");
        float arrivalProb = inputLoopProb("Enter the probability of a passenger arrival: ");
        float boardingProb = inputLoopProb("Enter the probability that a passenger is dequeued: ");
        float newFlightProb = inputLoopProb("Enter the probability that there is a new flight at RFK: ");
        int time = inputLoopNatural("Enter how many minutes this simulation should take: ", "That is not a valid minute! Please try again!");
        rng.setSeed(seed);
        System.out.println("\n\n\nStarting simulation ... \n");

        try {
            while(stopwatch < time) {
                //The display event method helps outputs if new flights should open while updating flight size
                statusOfAirForce1 = displayFlightEvents(stopwatch, eventsDQ, eventsEQ, events, newFlightProb, statusOfAirForce1, terminals, rng);
                events = ""; eventsEQ = ""; eventsDQ = ""; boarding = ""; departing = "";
                finalDepartingFlights = new Flight[airportCapacity]; departingIndex = 0;

                //Updates Final Departures for only Air Force 1 Flight
                if (airForce1 != null) {
                    statusOfAirForce1 = false;
                    finalDepartingFlights[departingIndex] = airForce1;
                    airForce1 = null;
                    departingIndex++;
                }

                //Checks out all active terminals
                flightIndex = 0;
                while (flightIndex < airportCapacity) {
                    jetliner = terminals[flightIndex];
                    if (jetliner != null && (!statusOfAirForce1 || jetliner.getAirForceStatus())) {
                        bq = jetliner.getBoardQueue();
                        currentlyBoarding = jetliner.isBoarding();

                        //Extends all new denatures and new boarding by 10 minutes in the presence of Covid Positive Passenger
                        if (covidPos) {
                            for (Flight jetTemp : terminals) {
                                if (jetTemp != null && (!statusOfAirForce1 || jetTemp.getAirForceStatus())) { //Check if current terminal and executes based on Air Force Status
                                    if (jetTemp.isBoarding()) { jetTemp.setMinutesLeftBoarding(jetTemp.getMinutesLeftBoarding() + 10); } //Extends boarding flights
                                    else { jetTemp.setMinutesLeftDeparting(jetTemp.getMinutesLeftDeparting() + 10); } //Extends departing flights
                                }
                            }
                            covidPos = false;
                        }

                        //Updates Final Flight Departures and Text for Non-Air Force 1 Flights
                        if (jetliner.getMinutesLeftDeparting() <= 0) {
                            finalDepartingFlights[departingIndex] = jetliner;
                            departingIndex++;
                            terminals[flightIndex] = null;
                        }

                        //Updates Departing Text and Departing Time
                        if (!(currentlyBoarding) && jetliner.getMinutesLeftDeparting() > 0) {
                            jetliner.setMinutesLeftDeparting(jetliner.getMinutesLeftDeparting() - 1);
                            if (!statusOfAirForce1) { //Determines if there is an Air Force 1 flight going on
                                departing += "- Flight to " + jetliner.getDestination() + " has " + jetliner.getTotalPassenger() + " passengers and "
                                        + jetliner.getMinutesLeftDeparting() + " minutes before departure\n";
                            } else {
                                departing += "- Air Force 1 flight to " + jetliner.getDestination() + " has " + jetliner.getTotalPassenger() + " passengers and "
                                        + jetliner.getMinutesLeftDeparting() + " minutes before departure\n";
                                if (jetliner.getMinutesLeftDeparting() == 0) { //Removes Air Force 1 flight from the terminal once its starts departing
                                    events += "- Air Force 1 has departed! Resuming departures and boarding\n";
                                    airForce1 = jetliner;
                                    terminals[flightIndex] = null;
                                }
                            }
                        }

                        //Section where all boarding related activities occur in
                        if (currentlyBoarding) {

                            //Updates Boarding to Departing Flights and Events Text
                            if (jetliner.getMinutesLeftBoarding() <= 0 || jetliner.getTotalPassenger() == jetliner.getPassengerCapacity()) {
                                jetliner.setBoarding(false);
                                if (!statusOfAirForce1) {
                                    events += "- Flight to " + jetliner.getDestination() + "  is now preparing for departure with "
                                            + jetliner.getTotalPassenger() + " passengers!\n";
                                } else {
                                    events += "- Air Force 1 Flight to " + jetliner.getDestination() + "  is now preparing for departure with "
                                            + jetliner.getTotalPassenger() + " passengers!\n";
                                }
                            }

                            //Only Displays Boarding Events Accordingly
                            if (!statusOfAirForce1) {
                                boarding += "- Flight to " + jetliner.getDestination() + " has " + jetliner.getMinutesLeftBoarding() + " minutes to board, "
                                        + jetliner.getTotalPassenger() + " passenger(s), and " + bq.getSize() + " person(s) waiting to board.\n";
                            } else { //Only Displays boarding events if there is no Air Force 1 at the airport
                                boarding += "- Air Force 1 Flight to " + jetliner.getDestination() + " has " + jetliner.getMinutesLeftBoarding() + " minutes to board, "
                                        + jetliner.getTotalPassenger() + " passenger(s), and " + bq.getSize() + " person(s) waiting to board.\n";
                            }

                            //Boarding (Dequeue) Section - Checks to see if anyone is there waiting & determines if the passenger waiting on queue should be boarded
                            if (rng.nextFloat() < boardingProb) {
                                try {
                                    keyPassenger = bq.dequeuePassenger();
                                    try {
                                        jetliner.addToFlight(keyPassenger);
                                        eventsDQ += "- " + keyPassenger.getStringPassClass() + " passenger (ID " + keyPassenger.getPassengerID() + ") on flight to "
                                                + jetliner.getDestination() + " has boarded on a " + keyPassenger.getStringSeatType() + " seat!\n";
                                    } catch (FlightIsFullException e) {
                                        eventsDQ += "- Passenger is attempting to enter boarding queue to flight to " + jetliner.getDestination()
                                                + " ... failed due to a recently full plane!\n";
                                    }
                                } catch (NoPassengerException e) {
                                    eventsDQ += "- Attempted to board a new passenger on flight to " + jetliner.getDestination()
                                            + " ... failed due to lack of passengers in boarding queue.\n";
                                }
                            }

                            //Waiting (Enqueue) Section - Checks to see if there is room and determines if a new passenger should arrive
                            if (rng.nextFloat() < arrivalProb) {
                                float classProb = rng.nextFloat();
                                Passenger.TravelClass passengerClassStatus = null; //covidPos = false;

                                //Generates Class Status of Passenger
                                if (classProb < 0.12) { passengerClassStatus = Passenger.TravelClass.FIRST; }
                                else if (0.12 <= classProb && classProb < 0.24) { passengerClassStatus = Passenger.TravelClass.BUSINESS; }
                                else if (0.24 <= classProb && classProb < 0.56) { passengerClassStatus = Passenger.TravelClass.PREMIUM_ECONOMY; }
                                else if (0.56 <= classProb && classProb < 0.98) { passengerClassStatus = Passenger.TravelClass.ECONOMY; }
                                else { covidPos = true; }

                                if (!covidPos) { //Checks to see if there is a covid passenger
                                    flightID++; //Increments the id number by one for each new passenger
                                    Passenger boardingPass = new Passenger(passengerClassStatus, flightID, stopwatch+1);

                                    try { //Enqueues the passenger
                                        bq.enqueuePassenger(boardingPass);
                                        //Updates events menu for new boarding passenger
                                        eventsEQ += "- " + boardingPass.getStringPassClass() + " passenger (ID " + boardingPass.getPassengerID() + ") on flight to "
                                                + jetliner.getDestination() + " has entered the flight's boarding queue!\n";
                                    } catch (NoRoomException ignored) {
                                        eventsEQ += "- New person looking to board flight to " + jetliner.getDestination()
                                                + " ... failed due to lack of space in boarding queue.\n";
                                    }
                                } else {
                                    eventsEQ += "- COVID positive passenger found attempting to board flight to " + jetliner.getDestination()
                                            + "! All current departures and boarding extended by 10 minutes!\n";
                                }
                            }

                            //Updates departure timer based on two conditions, the presence of Air Force 1 or if the current jetliner is an Air Force 1
                            jetliner.setMinutesLeftBoarding(jetliner.getMinutesLeftBoarding() - 1);
                        }
                    }
                    //Updaters
                    flightIndex++;
                }

                //Boarding & Departing Text Updater in the presence of Air Force 1
                if (statusOfAirForce1) {
                    boarding += "- Boarding will resume once Air Force 1 departs.\n";
                    departing += "- Departures will resume once Air Force 1 departs.\n";
                }

                displayOtherEvents(boarding, departing, finalDepartingFlights);
                stopwatch++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private static boolean displayFlightEvents(int time, String evMsgA, String evMsgB, String evMsgC, float fltProb, boolean airForStat, Flight[] port, Random rng) {
        System.out.println("Minute " + time);
        System.out.print("\nEvents:\n" + evMsgA + evMsgB + evMsgC);

        Scanner input = new Scanner(System.in);
        String inputKey;
        boolean flag = false, airForce = false;
        int portIndex = -1;

        if (rng.nextFloat() < fltProb) { //Determines if a new flight should arrive
            for (int i = 0; i < port.length && portIndex == -1; i++) { if (port[i] == null) { portIndex = i; } } //Finds an empty airport terminal
            if (portIndex == -1) { //If no airport terminal is not founded
                System.out.print("- Attempting to start boarding for new flight ... failed due to lack of open terminal.\n");
            } else if (rng.nextFloat() < 0.9) { //else determines if it becomes flight is an Air Force 1 flight or a normal flight
                System.out.print("- A new flight has a arrived!, Its destination is ... ");
                inputKey = input.next().toUpperCase();
                port[portIndex] = new Flight(inputKey, false);
            } else if (!airForStat) {
                System.out.print("- A new flight of Air Force 1 has a arrived!, Its destination is ... ");
                inputKey = input.next().toUpperCase();
                port[portIndex] = new Flight(inputKey, true);
                airForce = true;
            } else {
                System.out.print("- Attempting to start boarding for new Air Force 1 flight ... failed due to presence of another Air Force 1 Flight on this airport.\n");
            }
            flag = true; //Used to tell the methods if "Nothing to note" text should be displayed or not
        }

        //Determines what to print if event messages are empty
        if ((evMsgA + evMsgB + evMsgC).equals("") && !flag) System.out.print("Nothing to note...\n\n");
        else System.out.println();

        //Updates the status of the presence of Air Force 1
        return airForce || airForStat;
    }
    private static void displayOtherEvents(String boardMsg, String departMsg, Flight[] finDepFlt) {
        if (boardMsg.equals("")) boardMsg = "Nothing to note...\n";
        if (departMsg.equals("")) departMsg = "Nothing to note...\n";

        System.out.println("Currently Boarding:\n" + boardMsg);
        System.out.println("Departing:\n" + departMsg);
        System.out.println("Final Departures:");
        if (finDepFlt[0] != null ) {
            finDepFlt[0].displayFlightTable();
            for (int i = 1; i < finDepFlt.length && finDepFlt[i] != null; i++) finDepFlt[i].displayFlightTable();
            System.out.println("\n\n\n");
        } else System.out.println("Nothing to note...\n\n\n\n");
    }
    private static long inputLoopLong(String message, String error){
        Scanner input = new Scanner(System.in);
        do {
            try {
                System.out.print(message);
                return input.nextLong();
            } catch (InputMismatchException e) {
                System.out.println(error);
                input.nextLine();
            }
        } while (true);
    }
    private static int inputLoopNatural(String message, String error){
        Scanner input = new Scanner(System.in);
        do {
            try {
                System.out.print(message);
                int key = input.nextInt();
                if (key < 0) throw new InputMismatchException();
                return key;
            } catch (InputMismatchException e) {
                System.out.println(error);
                input.nextLine();
            }
        } while (true);
    }
    private static float inputLoopProb(String message) {
        Scanner input = new Scanner(System.in);
        do {
            try {
                System.out.print(message);
                float key = input.nextFloat();
                if (key < 0.0 || key > 1.0) throw new InputMismatchException();
                return key;
            } catch (InputMismatchException e) {
                System.out.println("That is not a valid probability! Please try again!");
                input.nextLine();
            }
        } while (true);
    }
}
