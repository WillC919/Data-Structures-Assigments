public class NoPassengerException extends Exception {
    public NoPassengerException() {
        super("There is currently no passenger on this queue");
    }
}
