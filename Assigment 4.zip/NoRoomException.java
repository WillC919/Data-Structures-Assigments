public class NoRoomException extends Exception {
    public NoRoomException() {
        super("There is currently no more room on this queue!");
    }
}
