public class Passenger {
    //Data-fields
    enum TravelClass { FIRST, BUSINESS, PREMIUM_ECONOMY, ECONOMY }
    private TravelClass passClass, seatType;
    private int passengerID, arrivalTime;

    //Constructor
    public Passenger(TravelClass passClass, int passengerID, int arrivalTime) {
        this.passClass = passClass;
        this.seatType = passClass;
        this.passengerID = passengerID;
        this.arrivalTime = arrivalTime;
    }

    //Getters
    public TravelClass getPassClass() { return passClass; }
    public String getStringPassClass() {
        if (passClass == TravelClass.FIRST) { return "First-Class"; }
        else if (passClass == TravelClass.BUSINESS) { return "Business-Class"; }
        else if (passClass == TravelClass.PREMIUM_ECONOMY) { return "Premium-Economy-Class"; }
        else if (passClass == TravelClass.ECONOMY) { return "Economy-Class"; }
        else { return "No given class"; }
    }
    public String getStringSeatType() {
        if (seatType == TravelClass.FIRST) { return "First-Class"; }
        else if (seatType == TravelClass.BUSINESS) { return "Business-Class"; }
        else if (seatType == TravelClass.PREMIUM_ECONOMY) { return "Premium-Economy-Class"; }
        else if (seatType == TravelClass.ECONOMY) { return "Economy-Class"; }
        else { return "No given seat type"; }
    }
    public int getPassengerID() { return passengerID; }
    public int getArrivalTime() { return arrivalTime; }

    //Setter
    public void setSeatType(TravelClass seatType) { this.seatType = seatType; }
}
