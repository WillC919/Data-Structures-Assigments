public class Person {
	//Data Fields
	private String name;
	private int seatNumber;
	private Person nextPerson;
	
	//Constructors 
	public Person() {
		name = null;
		seatNumber = -1;
		nextPerson = null;
	}
	public Person(String name) {
		this.name = name;
		seatNumber = -1;
		nextPerson = null;
	}
	
	//Getters
	public String getName() { return name; }
	public int getSeatNumber() { return seatNumber; }
	public Person getNextPerson() { return nextPerson; }
	
	//Setters
	public void setName(String name) { this.name = name; }
	public void setSeatNumber(int seatNumber) { this.seatNumber = seatNumber; }
	public void setNextPerson(Person nextPerson) { this.nextPerson = nextPerson; }
	
	public String toString(){
		String next;
		if (nextPerson == null) next = "NULL";
		else next = nextPerson.getName();
		return name + " with SN of " + seatNumber + " Next With " + next;
	}
}
