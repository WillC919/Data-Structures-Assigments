@SuppressWarnings("serial")
public class InvalidLineCountException extends Exception {
	public InvalidLineCountException() {
		super("The given number does not count");
	}
}
