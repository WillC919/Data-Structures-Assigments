public class SecurityCheck {
	private Line headLine;
	private Line cursorLine;
	private Line tailLine;
	private int lineCount;
	
	public SecurityCheck() {
		headLine = new Line();
		cursorLine = headLine;
		tailLine = headLine;
		lineCount = 1;
	}
	
	public void addPerson(String name, int seatNumber) throws TakenSeatException {
		if (!seatNumberAvailabilitylStatus(seatNumber)) throw new TakenSeatException(seatNumber); //Checks through all the lines if seat number is taken
		
		Person attendee = new Person(name); //Creates a new Person object to add the person
		attendee.setSeatNumber(seatNumber); //Sets the seat number for that person
		
		//Some variables to help the processing of this method
		cursorLine = headLine.getNextLine();
		Line keyLine = headLine;
		int keyLineLength = headLine.getLength(), i = 2, ithKey = 1;
			
		while (cursorLine != null) { //Traverse through the Linked List of Lines
			if (cursorLine.getLength() < keyLineLength) { //Check the length of each line so it can add the person to the shortest line to maintain condition 2
				keyLine = cursorLine; 
				ithKey = i; 
				break; //Ends the while loop once it found a shorter line
			} else {
				cursorLine = cursorLine.getNextLine();
				i++;
			}
		}
		keyLine.addPerson(attendee);
		System.out.println(name + " successfully added to line " + ithKey + "!");
		cursorLine = keyLine;
	}
	private boolean seatNumberAvailabilitylStatus(int seatNumber) { //Helper method used to check the seat number status, if free or taken
		boolean status = true;
		cursorLine = headLine;
		while (cursorLine != null && status) { //Traverse through the Linked List of Lines
			Person target = cursorLine.getHeadPerson(); 
			while (target != null) { //Traverse through the Linked List of Person in those Lines
				if (target.getSeatNumber() == seatNumber) { //Check the seat number of each person in this entire Security Check object if equal to the input
					status = false; 
					break; //Ends the search if its true
				}
				target = target.getNextPerson();
			}
			cursorLine = cursorLine.getNextLine();
		} 
		return status; //Returns the status of the availability of the seat number (True for free & False for taken)
	}
	
	public Person removeNextAttendee() throws AllLinesEmptyException {
		//Variables used in the processing of this method
		cursorLine = headLine;
		Line keyLine = cursorLine; 
		int keySeatNum, keyLength = cursorLine.getLength(), ithLine = 1, ithKey = ithLine;
		
		while (keyLength <= 0) { //Checks to see if there are any person in any lines before fully assigning the above variables
			cursorLine = cursorLine.getNextLine();
			ithLine++;
			if (cursorLine == null){ throw new AllLinesEmptyException(); //When cursorLine reaches the node after tail (null), it throws the AllLinesEmptyException
			} else if (cursorLine.getLength() > 0) {
				keyLength = cursorLine.getLength();
				ithKey = ithLine;
				System.out.print("Getting Line " + ithKey);
			}
		}
		
		keySeatNum = cursorLine.getHeadPerson().getSeatNumber();
		cursorLine = cursorLine.getNextLine(); //Continues to traverse through the other lines that haven't been traverse through yet
		
		while(cursorLine != null) { 
			if (cursorLine.getLength() > keyLength) { //Checks to see which line is the greater
				keyLength = cursorLine.getLength();
				keySeatNum = cursorLine.getHeadPerson().getSeatNumber();
				keyLine = cursorLine;
				ithKey = ithLine;
			} else if (cursorLine.getHeadPerson() == null) { //This just skips the next conditional statement in order to prevent NullPointerException
			} else if (cursorLine.getHeadPerson().getSeatNumber() < keySeatNum && keyLength == cursorLine.getLength() ) { //Checks to see their seat numbers
				keySeatNum = cursorLine.getHeadPerson().getSeatNumber();
				keyLine = cursorLine;
				ithKey = ithLine;
			}
			ithLine+=1;
			cursorLine = cursorLine.getNextLine();
		}
		
		Person keyPerson = keyLine.removeFrontPerson();
		System.out.println(keyPerson.getName() + " from seat " + keySeatNum + " removed from line " + ithKey + "!");
		return keyPerson;
	}
	
	public void addNewLines(int newLines) throws InvalidLineCountException {
		if (newLines < 0) throw new InvalidLineCountException(); //Throws error if the inputed value is negative
		else if (newLines > 0) { //Initializing and assigning some variables part
			int sumLength = 0, ithLine = lineCount; 
			lineCount += newLines; ///Updates the lineCount
			cursorLine = headLine;	
			while (cursorLine != null) { //Adds up all the person in Security Check object
				sumLength += cursorLine.getLength();
				cursorLine = cursorLine.getNextLine();
			}
			cursorLine = headLine; //Resets it for later use in this method
			
			//Creating New Lines Part	
			for (int i = newLines; i > 0; i--) { //Adds the new lines at the end of each line
				tailLine.setNextLine(new Line()); 
				tailLine = tailLine.getNextLine();
			}
			
			//The Console Output Statement Part
			if (newLines == 1) System.out.println("Loading...\nLines " + lineCount + " introduced!"); //Prints only if one line has been added
			else { //Prints a different statement when more than 1 line has been added
				System.out.print("Loading...\nLines "); 
				for(int i = ithLine + 1; i < lineCount; i++) {
					System.out.print(i);
					if(i < lineCount - 1) System.out.print(", ");
				}
				System.out.print(" and " + lineCount + " introduced!\n");
			}
			
			//Redistributing Part to maintain condition 1 & 2
			int balanceLength = sumLength / lineCount, lineRemainder = sumLength % lineCount, flip = 1; //The mathematical amount set to redistribute
			if (lineRemainder == 0) flip = 0; //To help in ways that condition 2 is properly met
			Person shiftedPerson = null; //The current person being removed
				
			while (cursorLine != null) { //Traverse through the linked list of lines
				if (cursorLine.getLength() <= balanceLength + 1*flip) { //Checks to see if current observed line is not exceeding its hold of persons  to ensure condition 2 is met
					cursorLine = cursorLine.getNextLine(); 
					if (lineRemainder > 1) lineRemainder--; //Measures the remainder by counting them in each line
					else flip = 0; //Ensures the remainders have already been accounted for and therefore stops counting them
				} else { 
					shiftedPerson = cursorLine.removeFrontPerson(); //Removes front person in the line
					
					Line destinationLine = cursorLine.getNextLine(), keyLine = cursorLine; 
					int keyLineLength = cursorLine.getLength();
					
					while (destinationLine != null) { //Puts the shifted person into the line with the fewest persons
						if (destinationLine.getLength() < keyLineLength) {
							keyLine = destinationLine;
							keyLineLength = destinationLine.getLength();
						}
						destinationLine = destinationLine.getNextLine();
					}
					keyLine.addPerson(shiftedPerson);
				}
			}
		} else System.out.println("No new lines were added");
	}	
	
	public void removeLines(int[] removedLines) throws LineDoesNotExistException, SingleLineRemovalException {
		//Some Data-Fields initialized 
		int removedLinesLength = removedLines.length;
		//Checking for 2 Possible Exception (LineDoesNotExistException & SingleLineRemovalException)
		for (int j = 0; j < removedLinesLength; j++) if (removedLines[j] > lineCount || removedLines[j] < 0) throw new LineDoesNotExistException(removedLines[j]);
		if (lineCount - removedLinesLength == 0) throw new SingleLineRemovalException();
		
		//Removing the Lines and taking out the People in the lines Part
		int tempCount = 0, oldLength = lineCount;
		cursorLine = headLine;
		Line prevTargetLine = null;
		Person[] bag = new Person[removedLinesLength*(headLine.getLength()+1)];
		boolean flag = false;
		
		for (int i = 1; i <= oldLength; i++) { //Traverse through the Security Check (Line Linked List)
			for (int j = 0; j < removedLinesLength; j++) { //Traverse through the array to be able to compare the line indexes to the number present in the array
				if (i == removedLines[j]) { //Starts removing the line and shifting all the people out of the line to be later redistributed.
					//Shifting the people on the lines part 
					int targetLength = cursorLine.getLength();
					for(int k = 0; k < targetLength; k++) { //Traverse through the Line (Person Linked List)
						bag[tempCount] = cursorLine.removeFrontPerson();
						tempCount++;
					}
					
					//Removing Lines Part
					if (prevTargetLine == null) { //When removing the old headLine
						headLine = headLine.getNextLine(); 
						lineCount--;
					} else {
						prevTargetLine.setNextLine(cursorLine.getNextLine()); //Just removes the line by removing it in the chain of linked list
						lineCount--;
					}
					flag = true; //Used to stop the advancement of the previous targeted line pointer to the next already-removed line
					break; //To exit the inner for-loop 
				}
			}
			if(flag) flag = false;
			else prevTargetLine = cursorLine; //Only moves when it there wasn't any recently removed line in that current iteration
			cursorLine = cursorLine.getNextLine(); //moves to observe the next line
		}
		
		//The Console Output Statement Part
		if (removedLinesLength == 1) System.out.print("Loading...\nLines " + removedLines[0] + " have been decommissioned!\n");
		else {
			System.out.print("Loading...\nLines ");
			for(int i = 0; i < removedLinesLength - 1; i++) {
				System.out.print((removedLines[i]));
				if(i < removedLinesLength - 2) System.out.print(", ");
			}
			System.out.print(" and " + removedLines[removedLinesLength - 1] + " have been decommissioned!\n");
		}
		
		//Redistribute of the list of person part to maintain condition 1 & 2
		for (int i = 0; i < tempCount; i++) {
			cursorLine = headLine.getNextLine();
			Line keyLine = headLine;
			int keyLineLength = headLine.getLength();
			
			while (cursorLine != null) { 
				if (cursorLine.getLength() < keyLineLength) { //This just puts the person into the current fewest persons in the line
					keyLine = cursorLine;
					keyLineLength = cursorLine.getLength();
				}
				cursorLine = cursorLine.getNextLine();
			}
			keyLine.addPerson(bag[i]); //This method maintains condition 1 thus better to use it instead of chunks of code for it
		}
	}
	
	//Methods used to help create the functioning of the mangerPanel method in the securityManger class
	public void displayLines() {
		System.out.println();
		cursorLine = headLine;
		int targetLineLength = 0, ithLine = 1;
		//Traverse through the linked list of lines to display the amount of people in that line
		while (cursorLine != null) {
			targetLineLength = cursorLine.getLength();
			if (targetLineLength != 1) {
				System.out.println("Line " + ithLine + ": " + targetLineLength + " People waiting");
				cursorLine = cursorLine.getNextLine();
				ithLine++;
			} else { //Different print statement if the line only has 1 person waiting
				System.out.println("Line " + ithLine + ": " + targetLineLength + " Person waiting");
				cursorLine = cursorLine.getNextLine();
				ithLine++;
			}
		}
		System.out.println();
	}
	public void displayTable() { //Prints out a neat formatted table of the contents in the Lines
		System.out.format("| %-10s| %-20s| %-13s|%n", "Line", "Name", "Seat Number");
		System.out.println("==================================================");
		cursorLine = headLine;
		for (int i = 1; i <= lineCount; i++) { //traverse through the linked list of lines
			Person temp = cursorLine.getHeadPerson();
			for (int j = 0; j < cursorLine.getLength(); j++) { //Traverse through the linked list of person to get each person in it to print its content out.
				System.out.format("| %-10s| %-20s| %-13s|%n", i, temp.getName(), temp.getSeatNumber());
				temp = temp.getNextPerson();
			}
			cursorLine = cursorLine.getNextLine();
		}
	}

	//Getter method
	public int getLineCount() {
		return lineCount;
	}
}

