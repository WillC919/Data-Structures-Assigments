@SuppressWarnings("serial")
public class TakenSeatException extends Exception {
	public TakenSeatException(int seatNumber) {
		super("Seat Number " + seatNumber + " is already taken");
	}
}
