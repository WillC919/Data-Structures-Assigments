@SuppressWarnings("serial")
public class AllLinesEmptyException extends Exception {
	public AllLinesEmptyException() {
		super("All Lines are currently empty");
	}
}
