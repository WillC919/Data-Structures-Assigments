@SuppressWarnings("serial")
public class SingleLineRemovalException extends Exception {
	public SingleLineRemovalException() {
		super("The given line if removed will result in no lines left");
	}
}
