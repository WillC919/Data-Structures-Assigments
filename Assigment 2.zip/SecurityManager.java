import java.util.InputMismatchException;
import java.util.Scanner;

public class SecurityManager {

	public static void main(String[] args) throws TakenSeatException {
		// TODO Auto-generated method stub
		SecurityCheck concertA = new SecurityCheck();
		
		/* Test Subjects
		concertA.addPerson("Alvin", 1);
		concertA.addPerson("Barry", 3);
		concertA.addPerson("Cassy", 5);
		concertA.addPerson("Daniel", 7);
		concertA.addPerson("Eric", 9);
		concertA.addPerson("Freddy", 2);
		concertA.addPerson("Gab", 4);
		concertA.addPerson("Holly", 6);
		concertA.addPerson("Izzy", 8);
		concertA.addPerson("James", 10);
		concertA.addPerson("Kevin", 12);
		concertA.addPerson("Larry", 11);
		*/
		
		managerPanel(concertA);
	}
	
	public static void managerPanel(SecurityCheck table) {
		boolean active = true; //The indicator whether to keep the program running
		boolean continueInput = true; //Used to continue a do-while loop if a proper input is not met
		
		System.out.println("Starting...");
		
		try {
			while (active) {
				table.displayLines();
				System.out.println("Menu:\n"
						+ "\t(A) � Add Person\n" 
						+ "\t(N) � Next Person\n" 
						+ "\t(R) � Remove Lines\n" 
						+ "\t(L) � Add New Lines\n" 
						+ "\t(P) � Print All Lines\n" 
						+ "\t(Q) � Quit\n" 
						+ "------------------------------------------------------------");
				System.out.println("Please select an option: ");
				
				Scanner input = new Scanner(System.in);
				String key = input.next().toUpperCase(); //.toUpperCase() Removes case sensitivity 
				String nameKey;
				int numKey;
				
				//Add Person "function"
				if (key.equals("A") || key.equals("(A)")) {
					System.out.println("Please enter a name: ");
					nameKey = input.next();
					do {
						System.out.println("Enter the Seat Number: ");
						try {
							numKey = input.nextInt();
							table.addPerson(nameKey, numKey); 
							continueInput = false; //Ends while loop
						} catch (TakenSeatException e) { //Catches an TakenSeatException and tells them to repeat the input
							System.out.println("That seat has alreay been taken!");
						} catch (InputMismatchException e) {
							System.out.println("That is not a vaild Seat Number. Please try again!");
							input.nextLine(); //Ask the user the input again
						}
					} while (continueInput); //Repeats the loop till it its imported properly
					continueInput = true; //Resets the value for repeating while loops
				
				//Next Person "function"
				} else if (key.equals("N") || key.equals("(N)")) { 
					try {
						table.removeNextAttendee();
					} catch (AllLinesEmptyException e) {
						System.out.println("No one to remove because all lines are currently empty");
					}
					
				//Remove Lines "function"	
				} else if (key.equals("R") || key.equals("(R)")) {
					
					System.out.println("Lines to remove: ");
					String line = input.next();
					try {
						String[] values = line.split(",");
						int[] numList = new int[values.length];
						for (int i = 0; i < values.length; i++) {
							numList[i] = Integer.parseInt(values[i]);
						}
						table.removeLines(numList);
					} catch (LineDoesNotExistException e) { //Catches error relating to the input of the user
						System.out.println("Some of the inputed line numbers does not exist.");
					} catch (SingleLineRemovalException e) { //Catches the removal of all lines error
						System.out.println("The lines given cannot be all deleted since there will no lines left.");
					} catch(InputMismatchException e) { //Catches an error in their input
						System.out.println("The inputed values are not vaild numbers.");
					} catch(IllegalArgumentException e) { //Catches an error in their input
						System.out.println("The inputed values are not vaild numbers.");
					}
				
				//New Lines "function"
				} else if (key.equals("L") || key.equals("(L)")) { 
					System.out.println("Add how many more lines?: ");
					do {
						try {
							numKey = input.nextInt();
							table.addNewLines(numKey);
							continueInput = false;
						} catch (InvalidLineCountException e) { //Catches an error in their input
							System.out.println("That is not a vaild input. Please try again!");
							input.nextLine(); //Ask the user the input again
						} catch(InputMismatchException e) { //Catches an error in their input
							System.out.println("The inputed value is not vaild number. Please try again!");
							input.nextLine();
						}
					} while(continueInput); //Repeats the loop till it its imported properly
					continueInput = true; //Resets the value for repeating while loops
					
				//Print Lines "function"	
				} else if (key.equals("P") || key.equals("(P)")) {
					table.displayTable();
				
				//Quit "function"
				} else if (key.equals("Q") || key.equals("(Q)")) {
					System.out.println("Sorry to see you go!");
					active = false;
				} else System.out.println("The input you entered is incorrect. Please try again!");
			}
		} catch (Exception e) { //Catches any error that occurs
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
