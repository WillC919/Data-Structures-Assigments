public class Line {
	private Person headPerson;
	private Person tailPerson;
	private int length;
	private Line lineLink;
	
	public Line() {
		headPerson = null;
		tailPerson = null;
		length = 0;
		lineLink = null;
	}
	
	public void addPerson(Person attendee) {
		if (headPerson == null) { //if there is no person in the line then, this sets the added as person the new head and tail person
			headPerson = attendee;
			tailPerson = headPerson;
			length++;
		} else { //else it continues to search through the line and adds the person in the proper place
			Person target = headPerson;
			Person prevTarget = null;
			int currentSeatNumber = attendee.getSeatNumber();
			
			for (int i = 1; i <= length; i++) {
				if (currentSeatNumber < target.getSeatNumber()) { //Used to help insert the person in there correct position in the line linked list
					attendee.setNextPerson(target);
					length++;
					if (prevTarget != null) prevTarget.setNextPerson(attendee); //Used to prevent NullPointerException
					else headPerson = attendee; //Helps establish new Head Person if there seat number is the lowest
					break; //End the for loop since the person was added in
				} else if (i == length) { //Used to set the added person as tail person if it is at the end of the linked list
					tailPerson.setNextPerson(attendee);
					tailPerson = attendee;
					length++;
					break; //End the for loop since the person was added in
				} else { //Advances / traverses through the linked list 
					prevTarget = target;
					target = target.getNextPerson();
				}
			}
		}
	}
	public Person removeFrontPerson() {
		if (headPerson == null) { // Check if there's any people in the line
			return null;
		} else { // Proceeds as its normally intended once condition is met
			Person removedHeadPerson = headPerson;
			headPerson = headPerson.getNextPerson(); //Sets the new headPerson
			length--;
			
			if(headPerson == null) tailPerson = null; //Sets the value of tailPerson if no person in the line after headPerson been removed
			else if (headPerson.getNextPerson() == null) tailPerson = headPerson; //sets the value of tailPerson if there is only one person in the line
			
			removedHeadPerson.setNextPerson(null); //Removes the connection it used to have - this is needed when it comes to adding the person back on a different line!!
			return removedHeadPerson; 
		}
	}
	
	//Helper Methods or Getters and Setters
	public Person getHeadPerson() { return headPerson; }
	public int getLength() { return length; }
	public Line getNextLine() { return lineLink; }
	public void setNextLine(Line nextLine) { lineLink = nextLine; }
}
