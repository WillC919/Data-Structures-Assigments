@SuppressWarnings("serial")
public class LineDoesNotExistException extends Exception {
	public LineDoesNotExistException(int i) {
		super("This line index number " + i + " does not exisit");
	}
}
